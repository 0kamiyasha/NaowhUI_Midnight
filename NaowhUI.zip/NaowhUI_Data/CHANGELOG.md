# NaowhUI_Data

## [20260117.01](https://github.com/rootkit1337tv/NaowhUI_Data/tree/20260117.01) (2026-01-17)
[Full Changelog](https://github.com/rootkit1337tv/NaowhUI_Data/compare/20260106.01...20260117.01) [Previous Releases](https://github.com/rootkit1337tv/NaowhUI_Data/releases)

- Updated WeakAura  
- Updated profile  
